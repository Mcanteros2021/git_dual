package com.logback.nttdata_projectlogback;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class Main {
	
	private static final Logger LOG = LoggerFactory.getLogger(Main.class);
	
	
	 public static void main(String[] args) {
		
		 
		 	// "APLICATIVO PARA INSERTAR UN NÚMERO EN LA POSICIÓN QUE SE LE ESPECIFICA"
		 
		 	LOG.info("COMIENZO");
		 	
		 	
		 	//ARRAY EN CUSTIÓN 
		 	
	        int[] v= {1,2,3,4,5};
	        
	        
	        LOG.debug("Array{}", v);
	        
	        
	        v = insertarValor(v,8,3);

	        
	       
	        
	        LOG.info("FINAL");

	    }
	
	 	// FUNCION DE INSERTAR VALOR
	
	public static int[] insertarValor(int[] v,int dato, int posicion) {

        int[] resultado = new int[v.length+1];

        for (int i = 0; i < v.length ; i++) {
            if (i<posicion) {
                resultado[i] = v[i];
            } else {
                resultado[i+1] = v[i];
            }
        }

        resultado[posicion] = dato;
        LOG.debug("Resultado: {}", resultado);
        return resultado;
    }

   
	

}
